import 'package:sqflite/sqflite.dart';
import 'model_sceen.dart';

class DataBaseHelper {
  Future<String> createDatabase() async {
    var path = await getDatabasesPath();
    var database = "$path/users.db";
    return database;
  }

  Future<Database> _openDatabase() async {
    var dbPath = await createDatabase();
    return await openDatabase(
      dbPath,
      version: 2, // Increment the version number
      onCreate: (Database db, int version) async {
        var tableQuery = '''
        CREATE TABLE person (
          id INTEGER PRIMARY KEY,
          image TEXT,
          title TEXT,
          description TEXT,
          location TEXT,
          country TEXT
      )
        ''';
        await db.execute(tableQuery);
      },
      onUpgrade: (Database db, oldVersion, newVersion) async {
        if (oldVersion < newVersion) {
          await db.execute('ALTER TABLE person ADD COLUMN country TEXT');
        }
      },
    );
  }

  Future<void> insertUser(DataModal data) async {
    var db = await _openDatabase();
    await db.insert('person', data.ModeltoMap());
  }

  Future<List<DataModal>> getUsersData() async {
    var db = await _openDatabase();
    List<DataModal> users = [];
    final data = await db.query('person');
    for (var d in data) {
      users.add(DataModal.MaptoModel(d));
    }
    return users;
  }

  Future<List<Map<String, Object?>>> getColumnData() async {
    var db = await _openDatabase();
    return await db.query('person', columns: ['image', 'title', 'description', 'location', 'country']);
  }

  Future<List<Map<String, Object?>>> getRowData(int id) async {
    var db = await _openDatabase();
    return await db.query('person', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> updateData(DataModal model) async {
    var db = await _openDatabase();
    await db.update(
      'person',
      model.ModeltoMap(),
      where: 'id = ?',
      whereArgs: [model.id],
    );
  }

  Future<void> deleteRow(int id) async {
    var db = await _openDatabase();
    await db.delete(
      'person',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}
