class DataModal {
  int? id;
  String? image;
  String? title;
  String? description;
  String? location;
  String? country; // Add country field

  DataModal({
    this.id,
    this.image,
    this.title,
    this.description,
    this.location,
    this.country, // Add country to constructor
  });

  // Convert a DataModal instance into a map.
  Map<String, dynamic> ModeltoMap() {
    return {
      'id': id,
      'image': image,
      'title': title,
      'description': description,
      'location': location,
      'country': country,
      // Add country to map
    };
  }

  // Create a DataModal instance from a map.
  factory DataModal.MaptoModel(Map<String, dynamic> map) {
    return DataModal(
      id: map['id'],
      image: map['image'],
      title: map['title'],
      description: map['description'],
      location: map['location'],
      country: map['country'], // Add country from map
    );
  }
}
