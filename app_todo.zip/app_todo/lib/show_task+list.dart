import 'dart:io';
import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'add_user.dart';
import 'databse_helper.dart';
import 'model_sceen.dart';

class ShowDataScreen extends StatefulWidget {
  const ShowDataScreen({super.key});

  @override
  _ShowDataScreenState createState() => _ShowDataScreenState();
}

class _ShowDataScreenState extends State<ShowDataScreen> {
  ConnectivityResult _connectivityStatus = ConnectivityResult.none;
  late DataBaseHelper _dbHelper;
  List<DataModal> _tasks = [];
  int? _selectedTaskId;

  @override
  void initState() {
    super.initState();
    _dbHelper = DataBaseHelper();
    _checkConnectivity();
    Connectivity().onConnectivityChanged.listen((ConnectivityResult result) {
      setState(() {
        _connectivityStatus = result;
      });
    });
    _fetchTasks();
  }

  Future<void> _checkConnectivity() async {
    ConnectivityResult result = await Connectivity().checkConnectivity();
    setState(() {
      _connectivityStatus = result;
    });
  }

  Future<void> _fetchTasks() async {
    try {
      List<DataModal> tasks = await _dbHelper.getUsersData();
      setState(() {
        _tasks = tasks;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to load tasks')),
      );
    }
  }

  void _showUpdateModal(DataModal task) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return UpdateForm(
            task: task,
            onUpdate: () {
              _fetchTasks();
              setState(() {
                // Navigator.pop(context);
              });
            });
      },
    );
  }

  Future<void> _deleteTask(int id) async {
    try {
      await _dbHelper.deleteRow(id);
      _fetchTasks();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to delete task')),
      );
    }
  }

  void _onCheckboxChanged(int id) {
    setState(() {
      _selectedTaskId = _selectedTaskId == id ? null : id; // Toggle selection
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        shape: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
        backgroundColor: Colors.blueGrey,
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddTaskScreen()),
          ).then((_) => _fetchTasks());
        },
      ),
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text(
          "Show Task",
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.blueGrey,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  _connectivityStatus == ConnectivityResult.wifi
                      ? Icons.wifi
                      : _connectivityStatus == ConnectivityResult.mobile
                          ? Icons.wifi
                          : Icons.wifi_off,
                  color: _connectivityStatus == ConnectivityResult.none
                      ? Colors.red
                      : Colors.green,
                ),
                Text(
                  _connectivityStatus == ConnectivityResult.none
                      ? "Disconnected"
                      : _connectivityStatus == ConnectivityResult.wifi
                          ? "Connected"
                          : "wifi connected",
                  style: TextStyle(
                    color: _connectivityStatus == ConnectivityResult.none
                        ? Colors.red
                        : Colors.green,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: _tasks.length,
        itemBuilder: (context, index) {
          final task = _tasks[index];
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(10),
              ),
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (task.image != null)
                    Image.file(
                      File(task.image!),
                      width: double.infinity,
                      height: 150,
                      fit: BoxFit.cover,
                    ),
                  const SizedBox(height: 20),
                  Text(
                    task.title ?? 'No Title',
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    task.description ?? 'No Description',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold, // Make description bold
                    ),
                  ),
                  if (task.location != null)
                    Text(
                      'Location: ${task.location}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold, // Make location bold
                      ),
                    ),
                  if (task.country != null)
                    Text(
                      'Country: ${task.country}',
                      style: const TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Checkbox(
                        value: _selectedTaskId == task.id,
                        onChanged: (bool? value) {
                          _onCheckboxChanged(task.id ?? 0);
                        },
                      ),
                      Expanded(
                        child: Text(
                          _selectedTaskId == task.id
                              ? 'Complete'
                              : 'Incomplete',
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.more_vert, color: Colors.white),
                        onPressed: () {
                          showMenu(
                            context: context,
                            position: RelativeRect.fromLTRB(
                              MediaQuery.of(context).size.width - 100,
                              0,
                              0,
                              MediaQuery.of(context).size.height - 200,
                            ),
                            items: [
                              const PopupMenuItem<String>(
                                value: 'update',
                                child: Text('Update'),
                              ),
                              const PopupMenuItem<String>(
                                value: 'delete',
                                child: Text('Delete'),
                              ),
                            ],
                          ).then((value) {
                            if (value == 'update') {
                              _showUpdateModal(task);
                            } else if (value == 'delete') {
                              _deleteTask(task.id ?? 0);
                            }
                          });
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class UpdateForm extends StatefulWidget {
  final DataModal task;
  final VoidCallback onUpdate;

  const UpdateForm({super.key, required this.task, required this.onUpdate});

  @override
  UpdateFormState createState() => UpdateFormState();
}

class UpdateFormState extends State<UpdateForm> {
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;
  late TextEditingController _locationController;
  late TextEditingController _countryController;
  late String _imagePath;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.task.title);
    _descriptionController =
        TextEditingController(text: widget.task.description);
    _locationController = TextEditingController(text: widget.task.location);
    _countryController = TextEditingController(text: widget.task.country);
    _imagePath = widget.task.image ?? '';
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _locationController.dispose();
    _countryController.dispose();
    super.dispose();
  }

  Future<void> updateData() async {
    try {
      final updatedTask = DataModal(
        id: widget.task.id,
        title: _titleController.text,
        description: _descriptionController.text,
        location: _locationController.text,
        image: _imagePath,
        country: widget.task.country,
      );

      await DataBaseHelper().updateData(updatedTask);

      setState(() {
        widget.onUpdate();
      });
    } catch (e) {
      print("Error updating data: $e");
    }
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _imagePath = pickedFile.path;
      });
    }
  }

  Future<void> _fetchCurrentLocation() async {
    try {
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      setState(() {
        _locationController.text =
            '${position.latitude}, ${position.longitude}';
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to get current location')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _titleController,
            decoration: const InputDecoration(labelText: 'Title'),
          ),
          TextField(
            controller: _descriptionController,
            decoration: const InputDecoration(labelText: 'Description'),
          ),
          const SizedBox(height: 10),
          _imagePath.isNotEmpty
              ? Image.file(
                  File(_imagePath),
                  width: 100,
                  height: 120,
                  fit: BoxFit.cover,
                )
              : const Placeholder(
                  fallbackHeight: 100,
                  fallbackWidth: 100,
                ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {
              setState(() {
                updateData();
                Navigator.pop(context);
              });
            },
            child: const Text('Update'),
          ),
          ElevatedButton(
            onPressed: _pickImage,
            child: const Text('Pick Image'),
          ),
        ],
      ),
    );
  }
}
