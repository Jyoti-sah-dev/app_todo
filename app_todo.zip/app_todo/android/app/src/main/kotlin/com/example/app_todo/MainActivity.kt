package com.example.app_todo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
